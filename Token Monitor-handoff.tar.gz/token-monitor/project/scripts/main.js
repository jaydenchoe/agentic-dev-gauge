// Main controller: direction switching + tweaks.

(function () {
  const TM = window.TokenMonitor;

  // Tweak state
  const tweaks = {
    system: true, claude: true, copilot: true, zhipu: true, local: true,
    spark: true, pulse: true, critThresh: 90,
  };
  window.TM_TWEAKS = tweaks;

  // Direction switcher
  const switcher = document.getElementById('switcher');
  const dirs = ['vitals', 'console', 'strata'];
  function activate(dir) {
    dirs.forEach(d => {
      document.getElementById(d).classList.toggle('hidden', d !== dir);
    });
    switcher.querySelectorAll('button').forEach(b => {
      b.classList.toggle('active', b.dataset.dir === dir);
    });
    localStorage.setItem('tm.dir', dir);
  }
  switcher.addEventListener('click', e => {
    const btn = e.target.closest('button[data-dir]');
    if (btn) activate(btn.dataset.dir);
  });
  activate(localStorage.getItem('tm.dir') || 'vitals');

  // Tweaks panel
  const tweaksPanel = document.getElementById('tweaks');
  const tweaksBtn   = document.getElementById('tweaksBtn');
  const tweaksClose = document.getElementById('tweaksClose');
  tweaksBtn.addEventListener('click', () => tweaksPanel.classList.toggle('open'));
  tweaksClose.addEventListener('click', () => tweaksPanel.classList.remove('open'));

  // Support host toolbar tweak toggle
  window.addEventListener('message', (e) => {
    if (!e.data) return;
    if (e.data.type === '__activate_edit_mode') tweaksPanel.classList.add('open');
    if (e.data.type === '__deactivate_edit_mode') tweaksPanel.classList.remove('open');
  });
  window.parent.postMessage({ type: '__edit_mode_available' }, '*');

  // Switch toggles
  document.querySelectorAll('.tweak-switch').forEach(sw => {
    sw.addEventListener('click', () => {
      const key = sw.dataset.key;
      if (!key) return;
      sw.classList.toggle('on');
      tweaks[key] = sw.classList.contains('on');
      applyTweaks();
    });
  });
  document.getElementById('simSpeed').addEventListener('change', e => {
    TM.setSpeed(parseFloat(e.target.value));
  });
  document.getElementById('critThresh').addEventListener('change', e => {
    tweaks.critThresh = parseInt(e.target.value, 10);
    applyTweaks();
  });

  function applyTweaks() {
    document.body.dataset.sparklines = tweaks.spark ? '1' : '0';
    document.body.dataset.pulse = tweaks.pulse ? '1' : '0';
    // section visibility in each direction
    for (const sec of ['system', 'claude', 'copilot', 'zhipu', 'local']) {
      document.querySelectorAll(`[data-section="${sec}"]`).forEach(el => {
        el.classList.toggle('hidden', !tweaks[sec]);
      });
    }
    document.body.dataset.critThresh = tweaks.critThresh;
  }
  applyTweaks();

  // Uptime
  const uptimeEl = document.getElementById('uptime');
  TM.subscribe((s) => { uptimeEl.textContent = TM.fmtDuration(s.uptimeSeconds); });

  // Kick off
  TM.start();

  // Mount direction views
  VitalsView.mount(document.getElementById('vitals'));
  ConsoleView.mount(document.getElementById('console'));
  StrataView.mount(document.getElementById('strata'));
})();
