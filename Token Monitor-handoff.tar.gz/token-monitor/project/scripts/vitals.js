// DIRECTION 01 · VITALS view — renders compact Apple-style dashboard.

(function () {
  const TM = window.TokenMonitor;

  // --- SVG ring helper ---
  function ring(size, stroke, value, color) {
    const r = (size - stroke) / 2;
    const c = 2 * Math.PI * r;
    const off = c * (1 - Math.min(100, Math.max(0, value)) / 100);
    return `
      <svg class="v-quota-ring" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
        <circle cx="${size/2}" cy="${size/2}" r="${r}" stroke="rgba(255,255,255,0.07)" stroke-width="${stroke}" fill="none"/>
        <circle cx="${size/2}" cy="${size/2}" r="${r}" stroke="${color}" stroke-width="${stroke}" fill="none"
          stroke-linecap="round"
          stroke-dasharray="${c.toFixed(2)}"
          stroke-dashoffset="${off.toFixed(2)}"
          transform="rotate(-90 ${size/2} ${size/2})"
          style="transition: stroke-dashoffset 0.6s ease, stroke 0.2s;"/>
      </svg>
    `;
  }

  function sparkPath(arr, w, h) {
    if (!arr.length) return '';
    const min = 0, max = 100;
    const dx = w / (arr.length - 1);
    let d = '';
    arr.forEach((v, i) => {
      const x = i * dx;
      const y = h - ((v - min) / (max - min)) * h;
      d += (i === 0 ? 'M' : 'L') + x.toFixed(1) + ' ' + y.toFixed(1);
    });
    return d;
  }

  function stateClass(v, crit) {
    if (v >= crit)  return 'v-state-crit';
    if (v >= crit - 10) return 'v-state-warn';
    return '';
  }
  function colorFor(v, crit) {
    if (v >= crit)  return '#f0453a';
    if (v >= crit - 10) return '#e0892a';
    return '#9aa0a7';
  }
  function accentColor(c, v, crit) {
    if (v >= crit) return '#f0453a';
    if (v >= crit - 10) return '#e0892a';
    return c;
  }

  function render(root) {
    const s = TM.state;
    const crit = parseInt(document.body.dataset.critThresh || '90', 10);

    // --- summary ---
    // avg LLM utilization = average of token-relevant metrics
    const llmVals = [s.claude.session.value, s.claude.weekly.value, s.claude.sonnet.value, s.copilot.premium.value, s.zhipu.monthly.value];
    const avg = llmVals.reduce((a,b) => a+b, 0) / llmVals.length;
    const remaining = (100 - avg);

    // system avg
    const sysAvg = (s.system.cpu.value + s.system.mem.value + s.system.disk.value) / 3;

    // nearest reset pill
    const maxed = Math.max(s.claude.session.value, s.copilot.premium.value, s.zhipu.monthly.value);
    const burnRate = (0.25 + 0.08 + 0.05).toFixed(2); // pct/s approx

    root.innerHTML = `
      <div class="v-summary">
        <div class="v-summary-primary">
          <span class="v-h">Token headroom</span>
          <div class="v-score">
            ${remaining.toFixed(0)}<em>%</em>
          </div>
          <div style="font-family:var(--mono); font-size: 11px; color: var(--v-muted);">
            across 3 providers · 5 quotas
          </div>
        </div>
        <div class="v-summary-stat">
          <span class="v-s-label">LLM avg</span>
          <span class="v-s-val" style="color: ${colorFor(avg, crit)}">${avg.toFixed(0)}%</span>
          <span class="v-s-sub">${llmVals.length} tracked</span>
        </div>
        <div class="v-summary-stat">
          <span class="v-s-label">System load</span>
          <span class="v-s-val" style="color: ${colorFor(sysAvg, crit)}">${sysAvg.toFixed(0)}%</span>
          <span class="v-s-sub">cpu · mem · disk</span>
        </div>
        <div class="v-summary-stat">
          <span class="v-s-label">Next reset</span>
          <span class="v-s-val">4<em style="font-family:var(--sans); font-weight:500; font-size:13px; color:var(--v-label);">h</em> 53<em style="font-family:var(--sans); font-weight:500; font-size:13px; color:var(--v-label);">m</em></span>
          <span class="v-s-sub">claude session</span>
        </div>
      </div>

      <!-- SYSTEM -->
      <section class="v-section" data-section="system">
        <div class="v-section-head">
          <span class="v-section-title">System vitals</span>
          <span class="v-section-meta">8-core · Apple Silicon · 32 GB</span>
        </div>
        <div class="v-system">
          ${sysTile('cpu',  s.system.cpu,  crit)}
          ${sysTile('mem',  s.system.mem,  crit)}
          ${sysTile('disk', s.system.disk, crit)}
        </div>
      </section>

      <!-- PROVIDERS -->
      <section class="v-section">
        <div class="v-section-head">
          <span class="v-section-title">AI coding agents</span>
          <span class="v-section-meta">live · ${new Date().toLocaleTimeString('en-US', {hour12:false})}</span>
        </div>
        <div class="v-providers">
          <div class="v-provider claude" data-section="claude">
            <div class="v-provider-head">
              <div class="v-provider-name"><span class="v-provider-mark"></span>Claude</div>
              <span class="v-plan-pill claude">${s.claude.plan}</span>
            </div>
            <div class="v-quota-rows">
              ${quotaRow(s.claude.session, '#e0892a', crit)}
              ${quotaRow(s.claude.weekly,  '#e0892a', crit)}
              ${quotaRow(s.claude.sonnet,  '#e0892a', crit)}
              ${quotaRow(s.claude.extra,   '#e0892a', crit)}
            </div>
          </div>

          <div class="v-provider copilot" data-section="copilot">
            <div class="v-provider-head">
              <div class="v-provider-name"><span class="v-provider-mark"></span>Copilot</div>
              <span class="v-plan-pill copilot">${s.copilot.plan}</span>
            </div>
            ${singleQuota(s.copilot.premium, '#79c0ff', crit)}
          </div>

          <div class="v-provider zhipu" data-section="zhipu">
            <div class="v-provider-head">
              <div class="v-provider-name"><span class="v-provider-mark"></span>ZhipuAI</div>
              <span class="v-plan-pill zhipu">${s.zhipu.plan}</span>
            </div>
            <div class="v-quota-rows">
              ${quotaRow(s.zhipu.monthly, '#a69dff', crit)}
              ${quotaRow(s.zhipu.mcp,     '#a69dff', crit)}
            </div>
          </div>
        </div>
      </section>

      <!-- LOCAL LLM -->
      <section class="v-section" data-section="local">
        <div class="v-section-head">
          <span class="v-section-title">Local models</span>
          <span class="v-section-meta">ollama · 3 endpoints</span>
        </div>
        <div class="v-local">
          ${localCard(s.local.ollama1)}
          ${localCard(s.local.ollama2)}
          ${localCard(s.local.ollama3)}
        </div>
      </section>
    `;
  }

  function sysTile(key, m, crit) {
    const sc = stateClass(m.value, crit);
    const h = TM.history['system.' + key] || [];
    const sparkW = 62, sparkH = 30;
    return `
      <div class="v-sys-tile ${sc}">
        <div>
          <div class="v-sys-name">${m.label}</div>
          <div class="v-sys-detail">${m.detail || ''}</div>
        </div>
        <div class="v-sys-val">${m.value.toFixed(0)}<span class="v-sys-unit">${m.unit}</span></div>
        <svg class="v-sys-spark" width="${sparkW}" height="${sparkH}" viewBox="0 0 ${sparkW} ${sparkH}" preserveAspectRatio="none">
          <path d="${sparkPath(h, sparkW, sparkH)}" fill="none" stroke="${colorFor(m.value, crit)}" stroke-width="1.25" stroke-linejoin="round" stroke-linecap="round" opacity="0.9"/>
        </svg>
        <div class="v-sys-track"><div class="v-sys-fill" style="width:${m.value.toFixed(1)}%;"></div></div>
      </div>
    `;
  }

  function quotaRow(m, col, crit) {
    const sc = stateClass(m.value, crit);
    return `
      <div class="v-quota ${sc}">
        ${ring(28, 3, m.value, accentColor(col, m.value, crit))}
        <div class="v-quota-labels">
          <span class="v-quota-label">${m.label}</span>
          <span class="v-quota-detail">${m.detail || ''}</span>
        </div>
        <div>
          <div class="v-quota-val">${m.value.toFixed(0)}<span class="v-quota-unit">${m.unit}</span></div>
          <div class="v-quota-abs">${m.absolute || ''}</div>
        </div>
      </div>
    `;
  }

  function singleQuota(m, col, crit) {
    const sc = stateClass(m.value, crit);
    return `
      <div class="v-single-quota ${sc}">
        ${ring(80, 6, m.value, accentColor(col, m.value, crit)).replace('v-quota-ring', 'v-single-ring')}
        <div class="v-single-labels">
          <span class="v-single-label">${m.label}</span>
          <span class="v-single-detail">${m.absolute || ''}</span>
          <span class="v-single-detail">${m.detail || ''}</span>
        </div>
        <div>
          <div class="v-single-val">${m.value.toFixed(0)}<span class="v-single-unit">${m.unit}</span></div>
        </div>
      </div>
    `;
  }

  function localCard(m) {
    if (!m.active) {
      return `
        <div class="v-local-card idle">
          <div class="v-local-name">${m.label}</div>
          <div class="v-local-val idle">IDLE</div>
          <div class="v-local-model">${m.model} · ${m.detail}</div>
        </div>
      `;
    }
    return `
      <div class="v-local-card">
        <div class="v-local-name">${m.label}</div>
        <div class="v-local-val">${m.value.toFixed(0)}<span style="font-size:10px;color:var(--v-label);margin-left:1px;">%</span></div>
        <div class="v-local-model">${m.model} · ${m.detail}</div>
        <div class="v-local-track"><div class="v-local-fill" style="width:${m.value.toFixed(1)}%"></div></div>
      </div>
    `;
  }

  window.VitalsView = {
    mount(root) {
      TM.subscribe(() => render(root));
      render(root);
    }
  };
})();
