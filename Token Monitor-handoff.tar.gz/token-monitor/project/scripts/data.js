// Shared live-data simulator for all three directions.
// Emits state on an interval; each view subscribes and renders.

(function () {
  const HISTORY = 60; // points per metric for sparklines

  const state = {
    system: {
      cpu:    { label: 'CPU',    value: 32, unit: '%', detail: '8 cores · 2.4 GHz' },
      mem:    { label: 'Memory', value: 51, unit: '%', detail: '16.4 / 32.0 GB' },
      disk:   { label: 'Disk',   value: 89, unit: '%', detail: '408 / 460 GB' },
    },
    claude: {
      plan: 'MAX 5×',
      session: { label: 'Session', value: 38, unit: '%', detail: 'resets in 4h 53m', absolute: '19k / 50k msg' },
      weekly:  { label: 'Weekly',  value: 62, unit: '%', detail: 'resets Sat 08:59', absolute: '310 / 500' },
      sonnet:  { label: 'Sonnet',  value: 14, unit: '%', detail: 'resets Mon 09:00', absolute: '70 / 500' },
      extra:   { label: 'Extra',   value: 0,  unit: '%', detail: 'pay-as-you-go',   absolute: '$0 / $100' },
    },
    copilot: {
      plan: 'PRO',
      premium: { label: 'Premium', value: 6, unit: '%', detail: 'resets 2026-05-01', absolute: '19 / 300 req' },
    },
    zhipu: {
      plan: 'MAX',
      monthly: { label: 'Monthly', value: 22, unit: '%', detail: 'resets 2026-05-01', absolute: '2.2M / 10M tok' },
      mcp:     { label: 'MCP Calls', value: 8, unit: '%', detail: 'resets 2026-05-01', absolute: '320 / 4,000' },
    },
    local: {
      ollama1: { label: 'Ollama · dev',    model: 'llama3.1:70b', value: 44, unit: '%', detail: 'VRAM 22/48 GB', active: true  },
      ollama2: { label: 'Ollama · fast',   model: 'qwen2.5:7b',   value: 12, unit: '%', detail: 'VRAM 6/24 GB',  active: true  },
      ollama3: { label: 'Ollama · vision', model: 'llava:13b',    value: 0,  unit: '%', detail: 'idle',          active: false },
    },
    uptimeSeconds: 2538, // 00:42:18
  };

  // per-metric rolling history for sparklines
  const history = {};
  function key(group, metric) { return group + '.' + metric; }
  function track(group, metric) {
    const k = key(group, metric);
    if (!history[k]) history[k] = Array.from({ length: HISTORY }, () => state[group][metric].value);
    return history[k];
  }

  // noise + drift so metrics feel alive
  function wiggle(v, amp, floor, ceil) {
    let n = v + (Math.random() - 0.5) * amp;
    if (n < floor) n = floor + Math.random() * 0.5;
    if (n > ceil) n = ceil - Math.random() * 0.5;
    return n;
  }

  const listeners = new Set();
  function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
  function emit() { for (const fn of listeners) fn(state, history); }

  let simSpeed = 1;
  function setSpeed(s) { simSpeed = s; }

  function tick() {
    // System jitters fast
    state.system.cpu.value    = wiggle(state.system.cpu.value,    14 * simSpeed, 3,  98);
    state.system.mem.value    = wiggle(state.system.mem.value,     1.2 * simSpeed, 30, 92);
    state.system.disk.value   = wiggle(state.system.disk.value,    0.05 * simSpeed, 88.9, 89.4);

    // update mem detail
    const memGB = (32 * state.system.mem.value / 100).toFixed(1);
    state.system.mem.detail = memGB + ' / 32.0 GB';

    // Claude drifts slowly up
    state.claude.session.value = Math.min(98, state.claude.session.value + Math.random() * 0.25 * simSpeed);
    state.claude.weekly.value  = Math.min(99, state.claude.weekly.value  + Math.random() * 0.06 * simSpeed);
    state.claude.sonnet.value  = Math.min(99, state.claude.sonnet.value  + Math.random() * 0.04 * simSpeed);
    state.claude.extra.value   = Math.min(99, state.claude.extra.value   + Math.random() * 0.02 * simSpeed);

    // Copilot drifts up slowly
    state.copilot.premium.value = Math.min(99, state.copilot.premium.value + Math.random() * 0.05 * simSpeed);

    // Zhipu moderate
    state.zhipu.monthly.value = Math.min(99, state.zhipu.monthly.value + Math.random() * 0.08 * simSpeed);
    state.zhipu.mcp.value     = Math.min(99, state.zhipu.mcp.value     + Math.random() * 0.10 * simSpeed);

    // Local LLM jitter
    state.local.ollama1.value = state.local.ollama1.active ? wiggle(state.local.ollama1.value, 12 * simSpeed, 5, 92) : 0;
    state.local.ollama2.value = state.local.ollama2.active ? wiggle(state.local.ollama2.value, 6 * simSpeed, 2, 60) : 0;
    state.local.ollama3.value = state.local.ollama3.active ? wiggle(state.local.ollama3.value, 6 * simSpeed, 2, 60) : 0;

    // push to history
    const all = [
      ['system', 'cpu'], ['system', 'mem'], ['system', 'disk'],
      ['claude', 'session'], ['claude', 'weekly'], ['claude', 'sonnet'], ['claude', 'extra'],
      ['copilot', 'premium'],
      ['zhipu', 'monthly'], ['zhipu', 'mcp'],
      ['local', 'ollama1'], ['local', 'ollama2'], ['local', 'ollama3'],
    ];
    for (const [g, m] of all) {
      const h = track(g, m);
      h.push(state[g][m].value);
      if (h.length > HISTORY) h.shift();
    }

    state.uptimeSeconds += 1;
    emit();
  }

  function fmtDuration(s) {
    const h = String(Math.floor(s / 3600)).padStart(2, '0');
    const m = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
    const sec = String(s % 60).padStart(2, '0');
    return `${h}:${m}:${sec}`;
  }

  // Public API
  window.TokenMonitor = {
    state, history, subscribe, tick, setSpeed, fmtDuration, HISTORY,
    start() {
      if (this._t) return;
      this._t = setInterval(() => tick(), 1000);
      tick();
    },
  };
})();
