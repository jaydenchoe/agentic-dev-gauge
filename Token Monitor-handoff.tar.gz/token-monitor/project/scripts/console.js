// DIRECTION 02 · CONSOLE — dense monospace grid with sparklines.

(function () {
  const TM = window.TokenMonitor;

  function sparkPath(arr, w, h) {
    if (!arr.length) return '';
    const dx = w / (arr.length - 1);
    return arr.map((v, i) => {
      const x = i * dx;
      const y = h - (Math.max(0, Math.min(100, v)) / 100) * h;
      return (i === 0 ? 'M' : 'L') + x.toFixed(1) + ' ' + y.toFixed(1);
    }).join('');
  }
  function sparkArea(arr, w, h) {
    const p = sparkPath(arr, w, h);
    if (!p) return '';
    return p + ` L ${w} ${h} L 0 ${h} Z`;
  }

  function stateFor(v, crit) {
    if (v >= crit) return 'crit';
    if (v >= crit - 10) return 'warn';
    return '';
  }

  function segs(v, crit) {
    const total = 20;
    const lit = Math.round((v / 100) * total);
    const s = stateFor(v, crit);
    let html = '';
    for (let i = 0; i < total; i++) {
      const on = i < lit;
      let cls = 'c-seg';
      if (on) {
        if (s === 'crit') cls += ' crit';
        else if (s === 'warn') cls += ' warn';
        else cls += ' on';
      }
      html += `<div class="${cls}"></div>`;
    }
    return `<div class="c-bar">${html}</div>`;
  }

  function row(name, tagType, tag, detail, m, histKey, crit) {
    const s = stateFor(m.value, crit);
    const h = TM.history[histKey] || [];
    const color = s === 'crit' ? '#f0453a' : s === 'warn' ? '#e0892a' : '#6f7682';
    return `
      <div class="c-row ${s}">
        <div class="c-row-id">
          <div class="c-row-name"><span class="c-row-tag ${tagType}">${tag}</span> ${name}</div>
          <div class="c-row-detail">${detail || ''}</div>
        </div>
        ${segs(m.value, crit)}
        <svg class="c-spark" width="110" height="22" viewBox="0 0 110 22" preserveAspectRatio="none">
          <path d="${sparkArea(h, 110, 22)}" fill="${color}" fill-opacity="0.12"/>
          <path d="${sparkPath(h, 110, 22)}" fill="none" stroke="${color}" stroke-width="1.2" stroke-linejoin="round"/>
        </svg>
        <div class="c-val ${s}">${m.value.toFixed(0)}<span class="u">${m.unit || '%'}</span></div>
      </div>
    `;
  }

  function miniQuota(m, plan, crit) {
    const s = stateFor(m.value, crit);
    const color = s === 'crit' ? '#f0453a' : s === 'warn' ? '#e0892a' : plan;
    return `
      <div class="c-mini ${s}" style="color:${color};">
        <span class="c-mini-label">${m.label}</span>
        <span class="c-mini-val ${s}">${m.value.toFixed(0)}<span class="u">${m.unit || '%'}</span></span>
        <div class="c-mini-detail">${m.absolute || m.detail || ''}</div>
        <div class="c-mini-track"><div class="c-mini-fill" style="width:${m.value.toFixed(1)}%;"></div></div>
      </div>
    `;
  }

  function render(root) {
    const s = TM.state;
    const crit = parseInt(document.body.dataset.critThresh || '90', 10);
    const llmAvg = (s.claude.session.value + s.claude.weekly.value + s.claude.sonnet.value + s.copilot.premium.value + s.zhipu.monthly.value) / 5;
    const maxUsed = Math.max(s.claude.session.value, s.claude.weekly.value, s.copilot.premium.value, s.zhipu.monthly.value);

    root.innerHTML = `
      <div class="c-ticker">
        <span>UPTIME <b>${TM.fmtDuration(s.uptimeSeconds)}</b></span>
        <span class="c-ticker-sep">│</span>
        <span>LLM AVG <b style="color:${stateFor(llmAvg,crit)==='crit'?'#f0453a':stateFor(llmAvg,crit)==='warn'?'#e0892a':'#f2f3f5'};">${llmAvg.toFixed(1)}%</b></span>
        <span class="c-ticker-sep">│</span>
        <span>PEAK <b>${maxUsed.toFixed(0)}%</b></span>
        <span class="c-ticker-sep">│</span>
        <span>CPU <b>${s.system.cpu.value.toFixed(0)}%</b></span>
        <span class="c-ticker-sep">│</span>
        <span>MEM <b>${s.system.mem.value.toFixed(0)}%</b></span>
        <span class="c-ticker-sep">│</span>
        <span>DISK <b style="color:${stateFor(s.system.disk.value,crit)==='crit'?'#f0453a':stateFor(s.system.disk.value,crit)==='warn'?'#e0892a':'#f2f3f5'};">${s.system.disk.value.toFixed(0)}%</b></span>
        <span class="c-ticker-sep">│</span>
        <span>ALERTS <b style="color:#e0892a;">0 warn · 0 crit</b></span>
      </div>

      <div class="c-board">
        <!-- LEFT: long list of all quotas + system -->
        <div class="c-panel">
          <div class="c-panel-head">
            <h3>All metrics</h3>
            <span class="sub">descending by utilization</span>
          </div>
          <div class="c-rows" id="cRowList"></div>
        </div>

        <!-- RIGHT: grouped quota cards -->
        <div class="c-panel">
          <div class="c-panel-head">
            <h3>By provider</h3>
            <span class="sub">token balance · ${new Date().toLocaleDateString()}</span>
          </div>
          <div class="c-quota-stack">
            <div class="c-quota-card claude" data-section="claude">
              <div class="c-quota-card-head">
                <h4>⬤ Claude</h4>
                <span class="plan">${s.claude.plan}</span>
              </div>
              <div class="c-mini-rows">
                ${miniQuota(s.claude.session, '#e0892a', crit)}
                ${miniQuota(s.claude.weekly,  '#e0892a', crit)}
                ${miniQuota(s.claude.sonnet,  '#e0892a', crit)}
                ${miniQuota(s.claude.extra,   '#e0892a', crit)}
              </div>
            </div>
            <div class="c-quota-card copilot" data-section="copilot">
              <div class="c-quota-card-head">
                <h4>⬤ Copilot</h4>
                <span class="plan">${s.copilot.plan}</span>
              </div>
              <div class="c-mini-rows">
                ${miniQuota(s.copilot.premium, '#79c0ff', crit)}
              </div>
            </div>
            <div class="c-quota-card zhipu" data-section="zhipu">
              <div class="c-quota-card-head">
                <h4>⬤ ZhipuAI</h4>
                <span class="plan">${s.zhipu.plan}</span>
              </div>
              <div class="c-mini-rows">
                ${miniQuota(s.zhipu.monthly, '#a69dff', crit)}
                ${miniQuota(s.zhipu.mcp,     '#a69dff', crit)}
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    // Build rows — sort so hottest float up
    const entries = [
      { section: 'system', html: row('CPU',       'sys',     'SYS',     s.system.cpu.detail,    s.system.cpu,    'system.cpu', crit),  v: s.system.cpu.value },
      { section: 'system', html: row('Memory',    'sys',     'SYS',     s.system.mem.detail,    s.system.mem,    'system.mem', crit),  v: s.system.mem.value },
      { section: 'system', html: row('Disk',      'sys',     'SYS',     s.system.disk.detail,   s.system.disk,   'system.disk', crit), v: s.system.disk.value },
      { section: 'claude', html: row('Session',   'claude',  'CLAUDE',  s.claude.session.absolute + ' · ' + s.claude.session.detail, s.claude.session, 'claude.session', crit), v: s.claude.session.value },
      { section: 'claude', html: row('Weekly',    'claude',  'CLAUDE',  s.claude.weekly.absolute  + ' · ' + s.claude.weekly.detail,  s.claude.weekly,  'claude.weekly',  crit), v: s.claude.weekly.value },
      { section: 'claude', html: row('Sonnet',    'claude',  'CLAUDE',  s.claude.sonnet.absolute  + ' · ' + s.claude.sonnet.detail,  s.claude.sonnet,  'claude.sonnet',  crit), v: s.claude.sonnet.value },
      { section: 'claude', html: row('Extra',     'claude',  'CLAUDE',  s.claude.extra.absolute   + ' · ' + s.claude.extra.detail,   s.claude.extra,   'claude.extra',   crit), v: s.claude.extra.value },
      { section: 'copilot',html: row('Premium',   'copilot', 'COPILOT', s.copilot.premium.absolute+ ' · ' + s.copilot.premium.detail, s.copilot.premium,'copilot.premium', crit), v: s.copilot.premium.value },
      { section: 'zhipu',  html: row('Monthly',   'zhipu',   'ZHIPUAI', s.zhipu.monthly.absolute  + ' · ' + s.zhipu.monthly.detail,  s.zhipu.monthly,  'zhipu.monthly',  crit), v: s.zhipu.monthly.value },
      { section: 'zhipu',  html: row('MCP Calls', 'zhipu',   'ZHIPUAI', s.zhipu.mcp.absolute      + ' · ' + s.zhipu.mcp.detail,      s.zhipu.mcp,      'zhipu.mcp',      crit), v: s.zhipu.mcp.value },
      { section: 'local',  html: row(s.local.ollama1.label, 'local', 'LOCAL', s.local.ollama1.model + ' · ' + s.local.ollama1.detail, s.local.ollama1, 'local.ollama1', crit), v: s.local.ollama1.value },
      { section: 'local',  html: row(s.local.ollama2.label, 'local', 'LOCAL', s.local.ollama2.model + ' · ' + s.local.ollama2.detail, s.local.ollama2, 'local.ollama2', crit), v: s.local.ollama2.value },
    ];
    const tw = window.TM_TWEAKS;
    const visible = entries.filter(e => tw[e.section]).sort((a,b) => b.v - a.v);
    document.getElementById('cRowList').innerHTML = visible.map(e => e.html).join('');
  }

  window.ConsoleView = {
    mount(root) {
      TM.subscribe(() => render(root));
      render(root);
    }
  };
})();
