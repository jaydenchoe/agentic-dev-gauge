// DIRECTION 03 · STRATA — bold editorial columns, serif numerals,
// token headroom as "fuel columns" depleting from the top.

(function () {
  const TM = window.TokenMonitor;

  function sparkPath(arr, w, h) {
    if (!arr.length) return '';
    const dx = w / (arr.length - 1);
    return arr.map((v, i) => {
      const x = i * dx;
      const y = h - (Math.max(0, Math.min(100, v)) / 100) * h;
      return (i === 0 ? 'M' : 'L') + x.toFixed(1) + ' ' + y.toFixed(1);
    }).join('');
  }

  function stateFor(v, crit) {
    if (v >= crit) return 'crit';
    if (v >= crit - 10) return 'warn';
    return '';
  }

  function fuelColumn(m, provider, plan, crit, fuelColor) {
    const used = m.value;
    const remaining = 100 - used;
    const s = stateFor(used, crit);

    // Build tick marks at 25/50/75
    const ticks = [25, 50, 75, 100].map(p => {
      const bottomPct = p;
      const major = p === 50 || p === 100;
      return `
        <div class="s-fuel-tick ${major?'major':''}" style="bottom:${bottomPct}%;"></div>
        <div class="s-fuel-tick-label" style="bottom:${bottomPct}%;">${p}</div>
      `;
    }).join('');

    return `
      <div class="s-col ${provider} ${s}" data-section="${provider}">
        <div class="s-col-head">
          <div class="s-col-plan">${plan}</div>
          <div class="s-col-name">${m.label}</div>
        </div>
        <div class="s-fuel" style="--fuel-color:${fuelColor};">
          <div class="s-fuel-ticks">${ticks}</div>
          <div class="s-fuel-remaining" style="height:${remaining.toFixed(1)}%;"></div>
        </div>
        <div class="s-col-val">
          <div class="big">${remaining.toFixed(0)}<em>% left</em></div>
          <div class="small">
            <b>${used.toFixed(0)}% used</b><br>
            ${m.absolute || ''}
          </div>
        </div>
        <div class="s-col-detail">${m.detail || ''}</div>
      </div>
    `;
  }

  function sysCell(key, m, crit) {
    const s = stateFor(m.value, crit);
    const h = TM.history['system.' + key] || [];
    return `
      <div class="s-sys-cell ${s}">
        <div class="k">${m.label}</div>
        <div class="v">${m.value.toFixed(0)}<em>%</em></div>
        <div class="sub">${m.detail || ''}</div>
        <svg class="spark" width="70" height="24" viewBox="0 0 70 24" preserveAspectRatio="none">
          <path d="${sparkPath(h, 70, 24)}" fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round" opacity="0.7"/>
        </svg>
        <div class="track"><div class="fill" style="width:${m.value.toFixed(1)}%;"></div></div>
      </div>
    `;
  }

  function localRow(m) {
    if (!m.active) {
      return `
        <div class="s-local-row idle">
          <span class="s-local-dot"></span>
          <div class="s-local-body">
            <div class="s-local-name">${m.label}</div>
            <div class="s-local-model">${m.model}</div>
          </div>
          <div class="s-local-val idle">IDLE</div>
        </div>
      `;
    }
    return `
      <div class="s-local-row">
        <span class="s-local-dot"></span>
        <div class="s-local-body">
          <div class="s-local-name">${m.label}</div>
          <div class="s-local-model">${m.model} · ${m.detail}</div>
        </div>
        <div class="s-local-val">${m.value.toFixed(0)}<em>%</em></div>
      </div>
    `;
  }

  function render(root) {
    const s = TM.state;
    const crit = parseInt(document.body.dataset.critThresh || '90', 10);
    const tw = window.TM_TWEAKS;

    const llmVals = [s.claude.session.value, s.claude.weekly.value, s.claude.sonnet.value, s.copilot.premium.value, s.zhipu.monthly.value];
    const avg = llmVals.reduce((a,b)=>a+b,0) / llmVals.length;
    const headroom = 100 - avg;

    // Assemble token columns across providers
    const columns = [];
    if (tw.claude) {
      columns.push(fuelColumn(s.claude.session, 'claude', 'CLAUDE · '+s.claude.plan, crit, '#e0892a'));
      columns.push(fuelColumn(s.claude.weekly,  'claude', 'CLAUDE · '+s.claude.plan, crit, '#e0892a'));
      columns.push(fuelColumn(s.claude.sonnet,  'claude', 'CLAUDE · '+s.claude.plan, crit, '#e0892a'));
      columns.push(fuelColumn(s.claude.extra,   'claude', 'CLAUDE · '+s.claude.plan, crit, '#e0892a'));
    }
    if (tw.copilot) {
      columns.push(fuelColumn(s.copilot.premium, 'copilot', 'COPILOT · '+s.copilot.plan, crit, '#79c0ff'));
    }
    if (tw.zhipu) {
      columns.push(fuelColumn(s.zhipu.monthly, 'zhipu', 'ZHIPUAI · '+s.zhipu.plan, crit, '#a69dff'));
      columns.push(fuelColumn(s.zhipu.mcp,     'zhipu', 'ZHIPUAI · '+s.zhipu.plan, crit, '#a69dff'));
    }

    // Tightest remaining
    const allQuotas = [
      s.claude.session, s.claude.weekly, s.claude.sonnet, s.claude.extra,
      s.copilot.premium, s.zhipu.monthly, s.zhipu.mcp,
    ];
    const tightest = allQuotas.reduce((a,b) => a.value > b.value ? a : b);

    root.innerHTML = `
      <div class="s-masthead">
        <div class="s-mast-primary">
          <div class="kicker">Token Monitor · ${new Date().toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' }).toUpperCase()}</div>
          <div class="title">
            ${headroom.toFixed(0)}<em>% headroom across agents</em>
          </div>
          <div class="rule"></div>
          <div class="sub">
            Tightest column is <b>${tightest.label}</b> at <b>${tightest.value.toFixed(0)}% used</b>.
            System is steady; disk at <b>${s.system.disk.value.toFixed(0)}%</b> is the warmest resource.
          </div>
        </div>
        <div class="s-mast-stat">
          <span class="k">LLM Avg used</span>
          <span class="v">${avg.toFixed(0)}<em>%</em></span>
          <span class="n">across ${llmVals.length} quotas</span>
        </div>
        <div class="s-mast-stat">
          <span class="k">Next reset</span>
          <span class="v">4<em>h</em> 53<em>m</em></span>
          <span class="n">claude · session</span>
        </div>
      </div>

      <section class="s-section">
        <div class="s-section-head">
          <span class="label">Token columns</span>
          <span class="count">${columns.length} tracked · filled = remaining</span>
        </div>
        <div class="s-columns">
          ${columns.join('')}
        </div>
      </section>

      <section class="s-section" data-section="system">
        <div class="s-section-head">
          <span class="label">Host resources</span>
          <span class="count">Apple Silicon · 32 GB · 460 GB SSD</span>
        </div>
        <div class="s-system">
          ${sysCell('cpu',  s.system.cpu,  crit)}
          ${sysCell('mem',  s.system.mem,  crit)}
          ${sysCell('disk', s.system.disk, crit)}
        </div>
      </section>

      <section class="s-section" data-section="local">
        <div class="s-section-head">
          <span class="label">Local models</span>
          <span class="count">ollama · 3 endpoints</span>
        </div>
        <div class="s-local-list">
          ${localRow(s.local.ollama1)}
          ${localRow(s.local.ollama2)}
          ${localRow(s.local.ollama3)}
        </div>
      </section>
    `;
  }

  window.StrataView = {
    mount(root) {
      TM.subscribe(() => render(root));
      render(root);
    }
  };
})();
